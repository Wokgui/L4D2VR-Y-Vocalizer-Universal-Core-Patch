@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_Y_VOCALIZER_UNIVERSAL.ps1"
