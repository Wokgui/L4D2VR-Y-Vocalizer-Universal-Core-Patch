﻿$ErrorActionPreference = "Stop"

function Get-SteamRoots {
    $roots = New-Object System.Collections.Generic.List[string]
    foreach ($rp in @(
        "HKCU:\Software\Valve\Steam",
        "HKLM:\Software\WOW6432Node\Valve\Steam",
        "HKLM:\Software\Valve\Steam"
    )) {
        try {
            $o = Get-ItemProperty $rp -ErrorAction Stop
            $steam = $o.SteamPath
            if (-not $steam) { $steam = $o.InstallPath }
            if ($steam -and (Test-Path $steam)) {
                $roots.Add($steam)
                $vdf = Join-Path $steam "steamapps\libraryfolders.vdf"
                if (Test-Path $vdf) {
                    $txt = Get-Content $vdf -Raw
                    foreach ($m in [regex]::Matches($txt, '"path"\s+"([^"]+)"')) {
                        $lib = $m.Groups[1].Value -replace '\\\\','\'
                        if ($lib -and (Test-Path $lib)) { $roots.Add($lib) }
                    }
                }
            }
        } catch {}
    }
    foreach ($drive in @("C:","D:","E:","F:","G:","H:")) {
        foreach ($p in @(
            "$drive\Steam",
            "$drive\SteamLibrary",
            "$drive\Program Files (x86)\Steam",
            "$drive\Program Files\Steam"
        )) {
            if (Test-Path $p) { $roots.Add($p) }
        }
    }
    return $roots | Select-Object -Unique
}
function Find-L4D2 {
    foreach ($r in Get-SteamRoots) {
        $p = Join-Path $r "steamapps\common\Left 4 Dead 2"
        if (Test-Path (Join-Path $p "left4dead2.exe")) { return $p }
    }
    try {
        Add-Type -AssemblyName System.Windows.Forms | Out-Null
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = "Select the Left 4 Dead 2 folder containing left4dead2.exe."
        $dlg.ShowNewFolderButton = $false
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            if (Test-Path (Join-Path $dlg.SelectedPath "left4dead2.exe")) { return $dlg.SelectedPath }
        }
    } catch {}
    return $null
}

$Expected = "793da6135b6893903c99a4430ec5b2c5c0269591503162a0426a8875b3fbb713"
$BackupName = "d3d9.L4D2VR.before_Y_Vocalizer_Universal.dll"

Clear-Host
Write-Host "L4D2VR - Y VOCALIZER UNIVERSAL" -ForegroundColor Cyan
Write-Host ""
Write-Host "Y opens the standard L4D2 radial named 'Orders'."
Write-Host "If a standard vocalizer replaces Orders, Y opens that vocalizer in the user's language."
Write-Host "If no vocalizer is installed, Y opens the native L4D2 Orders menu."
Write-Host ""

if (Get-Process left4dead2 -ErrorAction SilentlyContinue) {
    Write-Host "Close Left 4 Dead 2 before installing." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

$Game = Find-L4D2
if (-not $Game) {
    Write-Host "Left 4 Dead 2 was not found." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

$Source = Join-Path $PSScriptRoot "payload\d3d9.dll"
$Target = Join-Path $Game "d3d9.dll"
$Backup = Join-Path $Game $BackupName

if (-not (Test-Path $Target)) {
    Write-Host "The original L4D2VR mod does not appear to be installed." -ForegroundColor Red
    Write-Host "Install L4D2VR first, then run this installer again."
    Read-Host "Press Enter to exit"
    exit 1
}

$hash = (Get-FileHash $Source -Algorithm SHA256).Hash.ToLowerInvariant()
if ($hash -ne $Expected) { throw "Patch integrity check failed." }

if (-not (Test-Path $Backup)) {
    Copy-Item $Target $Backup -Force
}

Copy-Item $Source $Target -Force
$installed = (Get-FileHash $Target -Algorithm SHA256).Hash.ToLowerInvariant()
if ($installed -ne $Expected) { throw "Installation verification failed." }

Write-Host ""
Write-Host "INSTALLATION COMPLETE" -ForegroundColor Green
Write-Host ""
Write-Host "Y now opens: +mouse_menu Orders"
Write-Host "Standard vocalizer installed -> Y opens its Orders menu."
Write-Host "No vocalizer installed       -> Y opens native L4D2 Orders."
Write-Host ""
Write-Host "Start L4D2VR with -insecure."
Write-Host ""
Read-Host "Press Enter to close"
