﻿$ErrorActionPreference = "Stop"

function Get-SteamRoots {
    $roots = New-Object System.Collections.Generic.List[string]
    foreach ($rp in @(
        "HKCU:\Software\Valve\Steam",
        "HKLM:\Software\WOW6432Node\Valve\Steam",
        "HKLM:\Software\Valve\Steam"
    )) {
        try {
            $o = Get-ItemProperty $rp -ErrorAction Stop
            $steam = $o.SteamPath
            if (-not $steam) { $steam = $o.InstallPath }
            if ($steam -and (Test-Path $steam)) {
                $roots.Add($steam)
                $vdf = Join-Path $steam "steamapps\libraryfolders.vdf"
                if (Test-Path $vdf) {
                    $txt = Get-Content $vdf -Raw
                    foreach ($m in [regex]::Matches($txt, '"path"\s+"([^"]+)"')) {
                        $lib = $m.Groups[1].Value -replace '\\\\','\'
                        if ($lib -and (Test-Path $lib)) { $roots.Add($lib) }
                    }
                }
            }
        } catch {}
    }
    foreach ($drive in @("C:","D:","E:","F:","G:","H:")) {
        foreach ($p in @(
            "$drive\Steam",
            "$drive\SteamLibrary",
            "$drive\Program Files (x86)\Steam",
            "$drive\Program Files\Steam"
        )) {
            if (Test-Path $p) { $roots.Add($p) }
        }
    }
    return $roots | Select-Object -Unique
}
function Find-L4D2 {
    foreach ($r in Get-SteamRoots) {
        $p = Join-Path $r "steamapps\common\Left 4 Dead 2"
        if (Test-Path (Join-Path $p "left4dead2.exe")) { return $p }
    }
    try {
        Add-Type -AssemblyName System.Windows.Forms | Out-Null
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = "Select the Left 4 Dead 2 folder containing left4dead2.exe."
        $dlg.ShowNewFolderButton = $false
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            if (Test-Path (Join-Path $dlg.SelectedPath "left4dead2.exe")) { return $dlg.SelectedPath }
        }
    } catch {}
    return $null
}

$BackupName = "d3d9.L4D2VR.before_Y_Vocalizer_Universal.dll"

Clear-Host
Write-Host "L4D2VR - Y VOCALIZER UNIVERSAL UNINSTALLER" -ForegroundColor Cyan
Write-Host ""

if (Get-Process left4dead2 -ErrorAction SilentlyContinue) {
    Write-Host "Close Left 4 Dead 2 before uninstalling." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

$Game = Find-L4D2
if (-not $Game) {
    Write-Host "Left 4 Dead 2 was not found." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

$Target = Join-Path $Game "d3d9.dll"
$Backup = Join-Path $Game $BackupName

if (-not (Test-Path $Backup)) {
    Write-Host "No backup was found. Nothing was changed." -ForegroundColor Yellow
    Read-Host "Press Enter to close"
    exit 1
}

Copy-Item $Backup $Target -Force
Remove-Item $Backup -Force

Write-Host ""
Write-Host "Original L4D2VR d3d9.dll restored." -ForegroundColor Green
Write-Host ""
Read-Host "Press Enter to close"
