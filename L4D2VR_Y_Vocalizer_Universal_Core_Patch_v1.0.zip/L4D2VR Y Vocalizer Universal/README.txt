L4D2VR - Y VOCALIZER UNIVERSAL
===============================

PURPOSE
This patch makes the Y button open the standard Left 4 Dead 2 radial menu:
+mouse_menu Orders

WHY THIS IS UNIVERSAL
This package DOES NOT include radialmenu.txt and DOES NOT replace the player's vocalizer.

If the player has a standard vocalizer installed that replaces the Orders radial:
- Y opens that vocalizer.
- Its own language, phrases and layout are preserved.

If the player has no vocalizer installed:
- Y opens the normal Left 4 Dead 2 Orders radial.

REQUIREMENTS
- Left 4 Dead 2
- L4D2VR already installed
- -insecure launch option, as recommended by L4D2VR

INSTALL
1. Close Left 4 Dead 2.
2. Extract this ZIP.
3. Double-click INSTALL_Y_VOCALIZER_UNIVERSAL.bat.
4. Start SteamVR and L4D2VR.

UNINSTALL
Run UNINSTALL_Y_VOCALIZER_UNIVERSAL.bat.

NOTE
Steam Workshop cannot install or replace d3d9.dll in the game root.
Therefore this Core Patch must be downloaded separately from the Workshop item.

SHA256 d3d9.dll
793da6135b6893903c99a4430ec5b2c5c0269591503162a0426a8875b3fbb713
